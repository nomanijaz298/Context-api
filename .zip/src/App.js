import { Routes, Route, BrowserRouter } from "react-router-dom";
import Navbar from "./pages/Navbar";
import Home from "./pages/Home.js";
import Cart from "./pages/Cart.js";

function App() {
  return (
    <BrowserRouter>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cart" element={<Cart />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
