import React, { useContext, useEffect, useState } from "react";
import axios from "axios";
import { Cartcontext } from "../Context/context";

const Home = () => {
  const [products, setProducts] = useState([]);
  const [amount, setAmount] = useState(1);
  const getProduct = async () => {
    const res = await axios.get("https://fakestoreapi.com/products");
    setProducts(res.data);
  };

  const Globalstate = useContext(Cartcontext);
  const dispatch = Globalstate.dispatch;

  console.log(Globalstate);
  useEffect(() => {
    getProduct();
  }, []);
  return (
    <>
      <div className="container">
        <h1>Context API functionality</h1>
        <div className="row">
          {products.map((pro) => {
            pro.quantity = 1;
            return (
              <div className="card" style={{ width: "16rem" }}>
                <img
                  src={pro.image}
                  height={250}
                  className="card-img-top"
                  alt="..."
                />
                <div className="card-body">
                  <h5 className="card-title">{pro.title.slice(0, 30)}...</h5>
                  <p className="card-text">{pro.price}</p>
                  <button
                    className="btn btn-primary"
                    onClick={() => dispatch({ type: "ADD", payload: pro })}
                  >
                    ADD TO CART
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </>
  );
};

export default Home;
