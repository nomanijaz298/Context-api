import React, { useContext } from "react";
import { Cartcontext } from "../Context/context";

const Cart = () => {
  const Globalstate = useContext(Cartcontext);
  const state = Globalstate.state;
  const dispatch = Globalstate.dispatch;

  // Calculate total amount
  const totalAmount = state.reduce((total, pro) => {
    return total + pro.quantity * pro.price;
  }, 0);
  return (
    <>
      <div className="container">
        <div className="block-heading">
          <h2>Shopping Cart</h2>
        </div>
        <div className="content">
          <div className="row">
            <div className="col-md-12 col-lg-8">
              {state.map((pro, index) => {
                return (
                  <div className="items">
                    <div className="product">
                      <div className="row">
                        <div className="col-md-3">
                          <img
                            className="img-fluid mx-auto d-block image"
                            src={pro.image}
                            alt="img"
                          />
                        </div>
                        <div className="col-md-8">
                          <div className="info">
                            <div className="row">
                              <div className="col-md-3 product-name">
                                <div className="product-name">
                                  <a href="#">{pro.title}</a>
                                </div>
                              </div>
                              <div className="col-md-3 quantity">
                                <label htmlFor="quantity">Quantity:</label>
                                <button
                                  onClick={() =>
                                    dispatch({ type: "INCREASE", payload: pro })
                                  }
                                >
                                  +
                                </button>
                                <p>{pro.quantity}</p>
                                <button
                                  onClick={() => {
                                    if (pro.quantity > 1) {
                                      dispatch({
                                        type: "DECREASE",
                                        payload: pro,
                                      });
                                    } else {
                                      dispatch({
                                        type: "REMOVE",
                                        payload: pro,
                                      });
                                    }
                                  }}
                                >
                                  -
                                </button>
                              </div>
                              <div className="col-md-3 price">
                                <span>$:{pro.quantity * pro.price}</span>
                              </div>
                              <div className="col-md-3 ">
                                <span
                                  onClick={() =>
                                    dispatch({ type: "REMOVE", payload: pro })
                                  }
                                >
                                  x
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="col-md-12 col-lg-4">
              <div className="summary">
                <h3>Summary</h3>

                <div className="Total-amount">Total:{totalAmount}</div>
                <button
                  type="button"
                  className="btn btn-primary btn-lg btn-block"
                >
                  Checkout
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Cart;
