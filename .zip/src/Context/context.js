import { createContext, useReducer } from "react";

export const Cartcontext = createContext();

export const Context = ({ children }) => {
  const reducer = (state, action) => {
    switch (action.type) {
      case "ADD":
        const curState = state.filter((pro) => action.payload.id === pro.id);
        if (curState.length > 0) {
          return state;
        } else {
          return [...state, action.payload];
        }
      case "INCREASE":
        const curstate1 = state.map((pro) => {
          if (pro.id === action.payload.id) {
            return { ...pro, quantity: pro.quantity + 1 };
          } else {
            return pro;
          }
        });
        return curstate1;
      case "DECREASE":
        const curstate2 = state.map((pro) => {
          if (pro.id === action.payload.id) {
            return { ...pro, quantity: pro.quantity - 1 };
          } else {
            return pro;
          }
        });
        return curstate2;
      case "REMOVE":
        const curstate3 = state.filter((pro) => pro.id !== action.payload.id);
        return curstate3;
      default:
        return state;
    }
  };

  const [state, dispatch] = useReducer(reducer, []);
  const info = { state, dispatch };
  return <Cartcontext.Provider value={info}>{children}</Cartcontext.Provider>;
};
